
ESA Glaciers Climate Change Initiative (Glaciers_cci):  2017 inventory of ice marginal lakes in Greenland (IIML), v1
========

Publication Status:
-------------------

    Published with DOI - please see catalogue record for full abstract and citation text

CEDA Data Catalogue Page for this dataset:
------------------------------------------

    http://catalogue.ceda.ac.uk/uuid/7ea7540135f441369716ef867d217519

Data Status:
------------
    This dataset has been completed.

licence: 
--------
    Use of these data is covered by the following licence: 
    
    http://licences.ceda.ac.uk/image/data_access_condition/esacci_glaciers_terms_and_conditions.pdf
    
    When using these data you must cite them correctly using the citation given on the catalogue record.
   
Access:
-------
   Public data: access to these data is available to both registered and non-registered users.
   

